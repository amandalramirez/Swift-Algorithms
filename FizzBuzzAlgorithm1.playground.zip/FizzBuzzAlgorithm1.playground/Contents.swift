import UIKit


/* common problem that is asked.
 
 imagine you have a series of numbers that are in sequential order (e.g. 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20). if the number is divisible by 3, print "fizz"; if the number is divisible by 5, print "buzz"; and if divisible by both 3 and 5, print "fizzbuzz" */

//let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

//create an array of numbers from 1 to 1000
var oneThousandNumbers = [Int]()
for i in 1...1000 {
    oneThousandNumbers.append(i)
}

for num in oneThousandNumbers {
    
    if num % 3 == 0 && num % 5 == 0 { //or num % 15 == 0
        print("\(num) fizzbuzz")
    } else if num % 3 == 0 {
        print("\(num) fizz")
    } else if num % 5 == 0 {
        print("\(num) buzz")
    } else {
    print (num)
    }
    
}

