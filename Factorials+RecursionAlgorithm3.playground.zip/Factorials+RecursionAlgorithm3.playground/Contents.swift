import UIKit

//facorial of 3 (3!): 3*2*1 = 6
//facorial of 5 (5!): 5*4*3*2*1 = 120

//loop OR recursion ... to do facorials

//For Loop:

func factorialOfValue(value: UInt) -> UInt {
    
    if value == 0 {
        return 1
    }
    
    var product: UInt = 1
    
    for i in 1...value {
        product = product * i
        print(i)
    }
    
    return product
}

//print(factorialOfValue(3))
factorialOfValue(value: 4)


// Recursion:
func recursiveFactorialOfValue(value: UInt) -> UInt {
    if value == 0 {
        return 1
    }
    
    print(value)
    
    return value * recursiveFactorialOfValue(value: value - 1)
}

recursiveFactorialOfValue(value: 4)


