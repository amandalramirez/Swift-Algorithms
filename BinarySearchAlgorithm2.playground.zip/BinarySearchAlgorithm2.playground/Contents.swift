import UIKit

// obj: to search as efficiently as possible.
// Search inside an array, and return true if the search value is found, otherwise return false.

let numbers = [1, 2, 4, 7, 8, 13, 16, 17, 24, 36, 37, 39]

var hundred = [Int]()
for i in 1...100 {
    hundred.append(i)
}

// n
//loops n times. (n = the number of values in the array) NOT AS EFFICIENT
func linearSearchForSearchValue(searchValue: Int, array: [Int]) -> Bool {
    for num in array {
        if num == searchValue {
            return true
        }
    }
    return false
}

//log(n) ~ looping through roughly half of the array 
//this cuts the array in two, and looks at the value to the right.if the value is greater than the value we are searching for, then the search proceeds to cut the first half of the array into two (again),.if the value is once again greater than the value we are searching for, it repeats the process... cuts search time down (instead of looking at each individual value)
func binarySearchForSearchValue(searchValue: Int, array: [Int]) -> Bool {
    var leftIndex = 0
    var rightIndex = array.count - 1
    
    while leftIndex <= rightIndex {
        let middleIndex = (leftIndex + rightIndex)/2
        let middleValue = array[middleIndex]
        
        print("middleValue: \(middleValue), leftIndex: \(leftIndex), rightIndex: \(rightIndex), [\(array[leftIndex]), \(array[rightIndex])]")
        
        if middleValue == searchValue {
            return true
        }
        
        if searchValue < middleValue {
             rightIndex = middleIndex - 1
        }
        
        if searchValue > middleValue {
            leftIndex = middleIndex + 1
        }
        
    }
    return false
}


print(linearSearchForSearchValue(searchValue: 1, array: numbers))
print(linearSearchForSearchValue(searchValue: 5, array: numbers))

print(binarySearchForSearchValue(searchValue: 37, array: numbers))
print(binarySearchForSearchValue(searchValue: 39, array: hundred))
